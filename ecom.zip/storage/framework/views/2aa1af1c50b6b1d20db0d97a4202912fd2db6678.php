
<?php $__env->startSection("content"); ?>
<div class="container custom-login">
	<div class="row">
		<div class="col-sm-4 col-sm-offset-4">
			<form action="login" method="POST">
				<?php echo csrf_field(); ?>
			  <div class="form-group">
			  	<label for="exampleInputEmail">Email Address</label>
			    <input type="email" name="email" class="form-control" id="exampleInputEmail" placeholder="Email Address">
			  </div>
			  <div class="form-group">
			  	<label for="exampleInputPassword">Password</label>
			    <input type="password" name="password" class="form-control" id="exampleInputPassword" placeholder="Password">
			  </div>
			  <button type="submit" class="btn btn-default">Submit</button>
			</form>
		</div>
	</div>
</div>
<!-- <h1>Login Page</h1>
<button class="btn btn-primary">Click on me</button> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/login.blade.php ENDPATH**/ ?>