<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('products')->insert([
        	'name'=>'Oppo Mobile',
        	'price'=>'200',
        	'description'=>'Mobile phone',
        	'category'=>'mobile',
        	'gallery'=>'https://sp.yimg.com/ib/th?id=OP.8o6AHO55%2fA%2fKNQ474C474&o=5&pid=21.1&w=174&h=174'
        ]);
    }
}
